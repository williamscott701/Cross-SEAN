// $(function(){

//     // chrome.storage.sync.get('p1',function(budget){
//     //     $('#p1').text(budget.p1);
//     //     // $('#limit').text(budget.limit);
//     // });
//     function myfunction(text){

//         return 'FALSE' ;
//     }
//     $('#submit1').click(function(){
//         chrome.storage.sync.get(['p1'],function(budget){
//             $('#p1').text('Your Query : '+ $('#tweet1').val())
//             // $('#p2').text($('#tweet1').val());
//             val= myfunction($('#tweet1').val())
//             $('#p3').text('We claimed your query as '+val)
        
//         }); 
//     });
// });