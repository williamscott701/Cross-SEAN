$(document).ready(function() {

    chrome.tabs.query({ 'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT },
        function(tabs) {
            url__ = tabs[0].url

            var split = url__.split("/")
            var tweetID = split.pop();
            var status = split.pop();
            var userName = split.pop();
            var domain = split.pop();

            if (status == "status" && domain == "twitter.com") {
                $("#where").html("<b>Tweet Found <i class='fas fa-grin-stars' style='font-size:2em; color:gold'></i></b> </br>")
                $("#where").append("<b>Tweet ID: </b>" + tweetID + "</br>")
                $("#where").append("Connecting to server... Please wait!")
                $.ajax({
                    url: "http://192.168.29.83:5000/read_tweet",
                    data: { 'data': tweetID },
                    success: function(result) {
                        $("#where").html("<b>Tweet Found </b> <i class='fas fa-grin-stars' style='font-size:2em; color:gold'></i></br>")
                        $("#where").append("<b>Tweet ID: </b>" + tweetID + "</br>")
                        $("#where").append("<b>Harmonic Sentiment: </b>" + result.tweet_sentiment.toFixed(2) + "</br>")
                        $("#where").append("<b>Tweet Text: </b></br>" + result.tweet_text + "</br>")

                        $("#buttons").css('display', 'inline-block')
                    }
                });
            } else {
                $("#where").html("Looks like you are not in a twitter status page ;)")
            }


        }
    );

    $("#ask_cross_sean").click(function() {
        $("#cross_sean_results").html("<h5>Asking Cross-SEAN, Please Wait!<h5>")
        chrome.tabs.query({ 'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT },
            function(tabs) {
                url__ = tabs[0].url

                var split = url__.split("/")
                var tweetID = split.pop();
                var status = split.pop();
                var userName = split.pop();
                var domain = split.pop();

                if (status == "status" && domain == "twitter.com") {
                    $.ajax({
                        url: "http://192.168.29.83:5000/predict_tweet",
                        data: { 'data': tweetID },
                        success: function(d) {
                            $("#cross_sean_results").html("<h4>Cross-SEAN Says...</h4>")
                            $("#cross_sean_results").append("<b>Class: </b>" + d.class + "</br>")
                            $("#cross_sean_results").append("<b>Confidence: </b>" + d.confidence.toFixed(3) + "</br>")
                        }
                    });
                } else {}


            }
        );

    });

    $("#report_fake").click(function() {
        chrome.tabs.query({ 'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT },
            function(tabs) {
                url__ = tabs[0].url

                var split = url__.split("/")
                var tweetID = split.pop();
                var status = split.pop();
                var userName = split.pop();
                var domain = split.pop();

                if (status == "status" && domain == "twitter.com") {
                    $.ajax({
                        url: "http://192.168.29.83:5000/report_fake",
                        // type: "post",
                        data: { 'data': tweetID },
                        success: function(d) {
                            alert("Noted!, Your efforts are very helpful.")
                        }
                    });
                } else {}
            }
        );
    });

    $("#report_genuine").click(function() {
        chrome.tabs.query({ 'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT },
            function(tabs) {
                url__ = tabs[0].url

                var split = url__.split("/")
                var tweetID = split.pop();
                var status = split.pop();
                var userName = split.pop();
                var domain = split.pop();

                if (status == "status" && domain == "twitter.com") {
                    $.ajax({
                        url: "http://192.168.29.83:5000/report_genuine",
                        data: { 'data': tweetID },
                        success: function(d) {
                            alert("Noted!, Your efforts are very helpful.")
                        }
                    });
                } else {}
            }
        );
    });
});